import Runner as rn
def ChangeInitiater(data,filereports,apped,choice):
    
    version=input("enter the version you want to use for rerunning ")
    rn.runner(data,version,filereports,apped,choice)
   
